import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'تطبيق الخدمات',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: LoginScreen(),
    );
  }
}

class LoginScreen extends StatelessWidget {
  LoginScreen({Key? key}) : super(key: key);

  // Controllers لتخزين المدخلات من المستخدم
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('تسجيل الدخول'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: emailController,
              decoration: const InputDecoration(
                labelText: 'البريد الإلكتروني',
                labelStyle: TextStyle(color: Colors.blue),
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.email), // إضافة أيقونة
              ),
            ),
            const SizedBox(height: 16.0),
            TextField(
              controller: passwordController,
              decoration: const InputDecoration(
                labelText: 'كلمة المرور',
                labelStyle: TextStyle(color: Colors.blue),
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.lock), // إضافة أيقونة
              ),
              obscureText: true,
            ),
            const SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                // معالجة تسجيل الدخول
                final email = emailController.text;
                final password = passwordController.text;

                if (email == 'admin' && password == '12345') {
                  // الانتقال إلى الشاشة الرئيسية بعد تسجيل الدخول بنجاح
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const HomeScreen()),
                  );
                } else {
                  // عرض رسالة خطأ إذا كانت البيانات غير صحيحة
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('بيانات تسجيل الدخول غير صحيحة!'),
                    ),
                  );
                }
              },
              child: const Text('تسجيل الدخول'),
            ),
            TextButton(
              onPressed: () {
                // الانتقال إلى شاشة التسجيل
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const SignUpScreen()),
                );
              },
              child: const Text('إنشاء حساب جديد'),
            ),
          ],
        ),
      ),
    );
  }
}

class SignUpScreen extends StatelessWidget {
  const SignUpScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('إنشاء حساب جديد'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              decoration: const InputDecoration(
                labelText: 'الاسم الكامل',
                labelStyle: TextStyle(color: Colors.blue),
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.person), // إضافة أيقونة
              ),
            ),
            const SizedBox(height: 16.0),
            TextField(
              decoration: const InputDecoration(
                labelText: 'البريد الإلكتروني',
                labelStyle: TextStyle(color: Colors.blue),
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.email), // إضافة أيقونة
              ),
            ),
            const SizedBox(height: 16.0),
            TextField(
              decoration: const InputDecoration(
                labelText: 'كلمة المرور',
                labelStyle: TextStyle(color: Colors.blue),
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.lock), // إضافة أيقونة
              ),
              obscureText: true,
            ),
            const SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                // قم بمعالجة إنشاء الحساب هنا
                print('تم إنشاء الحساب بنجاح!');
              },
              child: const Text('إنشاء الحساب'),
            ),
            TextButton(
              onPressed: () {
                // العودة إلى شاشة تسجيل الدخول
                Navigator.pop(context);
              },
              child: const Text('العودة إلى تسجيل الدخول'),
            ),
          ],
        ),
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الصفحة الرئيسية'),
      ),
      body: const Center(
        child: Text(
          'مرحبًا بك في تطبيق الخدمات!',
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}
