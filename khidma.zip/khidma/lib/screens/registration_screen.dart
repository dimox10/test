import 'package:flutter/material.dart';

class RegistrationScreen extends StatelessWidget {
  const RegistrationScreen({Key? key}) : super(key: key); // إضافة key وجعل الـ constructor ثابتًا.

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Registration Screen'), // إضافة const
      ),
      body: const Center(
        child: Text(
          'Welcome to the Registration Screen!',
          style: TextStyle(fontSize: 20), // إضافة const
        ),
      ),
    );
  }
}
