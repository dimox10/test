import 'package:flutter/material.dart';

/// واجهة التطبيق الرئيسية
void main() {
  runApp(const MyApp());
}

/// تطبيق Flutter
class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key); // أضف معلمة key

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Drag and Drop Example',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const ExampleDragSource(), // أضف const
    );
  }
}

/// صفحة السحب والإفلات
class ExampleDragSource extends StatelessWidget {
  const ExampleDragSource({Key? key}) : super(key: key); // أضف معلمة key

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flutter Drag and Drop Example'), // أضف const
      ),
      body: const Center( // أضف const
        child: Text(
          'Drag and Drop Example',
          style: TextStyle(fontSize: 20), // أضف const
        ),
      ),
    );
  }
}
